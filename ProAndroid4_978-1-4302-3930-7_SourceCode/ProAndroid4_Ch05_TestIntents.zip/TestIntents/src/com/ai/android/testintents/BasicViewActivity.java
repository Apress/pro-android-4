package com.ai.android.testintents;

import android.app.Activity;
import android.os.Bundle;

public class BasicViewActivity extends Activity 
{
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basic_view);
    }
}//eof-class
