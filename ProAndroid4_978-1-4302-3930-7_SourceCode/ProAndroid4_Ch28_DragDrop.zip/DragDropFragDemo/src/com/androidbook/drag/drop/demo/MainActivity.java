package com.androidbook.drag.drop.demo;

//This file is MainActivity.java
import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}